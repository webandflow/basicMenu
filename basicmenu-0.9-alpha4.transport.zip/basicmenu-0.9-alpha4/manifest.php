<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5edd9773e0b9f0bfeece0e69634d6c21',
      'native_key' => 'basicmenu',
      'filename' => 'modNamespace/d816ef6d4038ea454a194a2b658df59a.vehicle',
      'namespace' => 'basicmenu',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3a64f087e3dac2cbbe9177d6a07275c5',
      'native_key' => 1,
      'filename' => 'modCategory/599701a65676ed186d28e71b0933ad2b.vehicle',
      'namespace' => 'basicmenu',
    ),
  ),
);