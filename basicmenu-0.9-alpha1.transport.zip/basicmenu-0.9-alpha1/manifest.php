<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1f834fb52c6105d720b7b84ea869ddd7',
      'native_key' => 'basicmenu',
      'filename' => 'modNamespace/19f85c8690c3d8dfd52564a1d8ba11c1.vehicle',
      'namespace' => 'basicmenu',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ca8746980ca35386a3d0aefc0408adb7',
      'native_key' => 1,
      'filename' => 'modCategory/46a639e56b4a5d81362e94faab315dd2.vehicle',
      'namespace' => 'basicmenu',
    ),
  ),
);